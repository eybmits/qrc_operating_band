# QRC Operating Band source package

Compile with:

```bash
pdflatex qrc_phase_diagram.tex
pdflatex qrc_phase_diagram.tex
```

This package is intentionally flat so relative paths such as generated/ and gfx/ resolve on upload systems.
